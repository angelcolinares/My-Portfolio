import tkinter as tk
from tkinter import ttk, messagebox
import datetime
import traceback
import json
import os

# --- CONSTANTS ---
DATA_FILE = "scholarships.json"
LOG_FILE = "scholarship_logs.json"

# ---------- COLOR PALETTE CONSTANTS (Adjusted to image) ----------
PRIMARY_BG = "#1A1A1A"  # Very dark background
CARD_BG = "#2C2C2C"  # Slightly lighter dark for cards
TEXT_COLOR = "#FFFFFF"  # White text
SECONDARY_TEXT_COLOR = "#B0B0B0"  # Lighter gray for less prominent text
ACCENT_BLUE = "#007BFF"  # Blue for "View Details" and save buttons
ACCENT_GREEN = "#28A745"  # Green for successful saves
ACCENT_RED = "#DC3545"  # Red for delete/cancel buttons
STATUS_APPLIED_COLOR = "#28A745"  # Green
STATUS_PENDING_COLOR = "#FFC107"  # Yellow/Orange
STATUS_REJECTED_COLOR = "#DC3545"  # Red (This is the correct one to use for rejected/cancelled status)
STATUS_DRAFT_COLOR = "#6C757D"  # Gray
EDIT_ICON_COLOR = "#17A2B8"  # Cyan/Teal
DELETE_ICON_COLOR = "#DC3545"  # Red
FIELD_BG = "#3C3C3C"  # Background for entry/text fields
FIELD_TEXT = "#E0E0E0"  # Text color for entry/text fields
BUTTON_HOVER_COLOR = "#0056B3"  # Darker blue for general button hover


# ---------- DATABASE CLASS WITH PERSISTENCE ----------
class Database:
    def __init__(self):
        print("DEBUG: Database __init__ called.")
        self.scholarships = []
        self.logs = []
        self._load_data()

    def _load_data(self):
        """Loads scholarship data from the JSON file."""
        print(f"DEBUG: Loading data from {DATA_FILE}...")
        if os.path.exists(DATA_FILE) and os.path.getsize(DATA_FILE) > 0:
            try:
                with open(DATA_FILE, 'r', encoding='utf-8') as f:
                    self.scholarships = json.load(f)
                print(f"DEBUG: Loaded {len(self.scholarships)} scholarships from {DATA_FILE}.")
            except json.JSONDecodeError as e:
                print(f"ERROR: Could not decode JSON from {DATA_FILE}: {e}")
                self.scholarships = []
                messagebox.showerror("Data Error",
                                     f"Error reading scholarship data file: {e}\nStarting with empty data.")
            except Exception as e:
                print(f"ERROR: An unexpected error occurred while loading {DATA_FILE}: {e}")
                self.scholarships = []
                messagebox.showerror("Data Error",
                                     f"An unexpected error occurred while loading data: {e}\nStarting with empty data.")
        else:
            print(f"DEBUG: {DATA_FILE} not found or is empty. Initializing with empty list.")
            self._save_data()

        print(f"DEBUG: Loading logs from {LOG_FILE}...")
        if os.path.exists(LOG_FILE) and os.path.getsize(LOG_FILE) > 0:
            try:
                with open(LOG_FILE, 'r', encoding='utf-8') as f:
                    self.logs = json.load(f)
                print(f"DEBUG: Loaded {len(self.logs)} logs from {LOG_FILE}.")
            except json.JSONDecodeError as e:
                print(f"ERROR: Could not decode JSON from {LOG_FILE}: {e}")
                self.logs = []
                messagebox.showerror("Log Data Error", f"Error reading log file: {e}\nStarting with empty logs.")
            except Exception as e:
                print(f"ERROR: An unexpected error occurred while loading {LOG_FILE}: {e}")
                self.logs = []
                messagebox.showerror("Log Data Error",
                                     f"An unexpected error occurred while loading logs: {e}\nStarting with empty logs.")
        else:
            print(f"DEBUG: {LOG_FILE} not found or is empty. Initializing with empty logs.")
            self._save_logs()

    def _save_data(self):
        """Saves current scholarship data to the JSON file."""
        print(f"DEBUG: Saving data to {DATA_FILE}...")
        try:
            with open(DATA_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.scholarships, f, indent=4)
            print(f"DEBUG: Data saved to {DATA_FILE}.")
        except Exception as e:
            print(f"ERROR: Failed to save data to {DATA_FILE}: {e}")
            messagebox.showerror("Save Error", f"Failed to save scholarship data: {e}")

    def _save_logs(self):
        """Saves current log data to the JSON file."""
        print(f"DEBUG: Saving logs to {LOG_FILE}...")
        try:
            with open(LOG_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.logs, f, indent=4)
            print(f"DEBUG: Logs saved to {LOG_FILE}.")
        except Exception as e:
            print(f"ERROR: Failed to save logs to {LOG_FILE}: {e}")
            messagebox.showerror("Save Log Error", f"Failed to save log data: {e}")

    def fetch_all(self):
        print("DEBUG: Database fetch_all called.")
        return [dict(s) for s in self.scholarships]

    def insert(self, data):
        print(f"DEBUG: Database insert called with {data.get('name')}")
        if any(sch['name'] == data['name'] for sch in self.scholarships):
            raise ValueError(f"Scholarship with name '{data['name']}' already exists.")
        # Ensure these fields exist, even if empty for new scholarships
        data.setdefault("awarded_amount", "₱0")
        data.setdefault("disbursed_amount", "₱0")
        self.scholarships.append(data)
        self._save_data()
        print(f"DB: Inserted '{data['name']}'")

    def update(self, original_name, new_data):
        print(f"DEBUG: Database update called for {original_name}")
        found = False
        for i, sch in enumerate(self.scholarships):
            if sch.get("name") == original_name:
                # Ensure awarded_amount and disbursed_amount are carried over or updated
                new_data.setdefault("awarded_amount", sch.get("awarded_amount", "₱0"))
                new_data.setdefault("disbursed_amount", sch.get("disbursed_amount", "₱0"))
                self.scholarships[i] = new_data
                found = True
                break
        if not found:
            raise ValueError(f"Scholarship '{original_name}' not found for update.")
        self._save_data()
        print(f"DB: Updated '{original_name}' to '{new_data['name']}'")

    def delete(self, name):
        print(f"DEBUG: Database delete called for {name}")
        original_count = len(self.scholarships)
        self.scholarships = [sch for sch in self.scholarships if sch.get("name") != name]
        if len(self.scholarships) == original_count:
            raise ValueError(f"Scholarship '{name}' not found for deletion.")
        self._save_data()
        print(f"DB: Deleted '{name}'")

    def insert_log(self, date, name, amount_awarded, amount_disbursed, action):
        log_entry = {"date": date, "name": name, "awarded": amount_awarded, "disbursed": amount_disbursed,
                     "action": action}
        self.logs.append(log_entry)
        self._save_logs()
        print(f"DB Log: {date} - {name} ({action})")


database = Database()


class ScholarshipApp:
    def __init__(self, root):
        self.root = root
        self.root.title("My Scholarships")
        self.root.configure(bg=PRIMARY_BG)
        self.root.geometry("1200x800+100+100")
        self.root.state('zoomed')
        self.root.resizable(True, True)

        self.all_scholarships = []
        self.displayed_scholarships = []
        self.current_data = {}
        self.original_scholarship_name = None
        self.canvas_frame_id = None
        self.scholarship_list_tree = None # Initialize Treeview attribute

        try:
            print("DEBUG: Calling _setup_styles...")
            self._setup_styles()
            print("DEBUG: _setup_styles completed.")

            print("DEBUG: Calling display_dashboard from __init__...")
            self.display_dashboard() # Start with the new dashboard view
            print("DEBUG: display_dashboard from __init__ completed.")
        except Exception as e:
            print(f"ERROR: An unhandled error occurred during app initialization: {e}")
            traceback.print_exc()
            messagebox.showerror("Initialization Error",
                                 f"Failed to initialize application: {e}\nCheck console for details.")
            self.root.destroy()

    def _setup_styles(self):
        """ Configures all ttk styles for the application. """
        print("DEBUG: _setup_styles method started.")
        try:
            style = ttk.Style()
            style.theme_use("clam")

            # General styles
            style.configure("TFrame", background=PRIMARY_BG)
            style.configure("TLabel", background=PRIMARY_BG, foreground=TEXT_COLOR)

            # Buttons
            style.configure("TButton", font=("Arial", 10, "bold"), borderwidth=0, relief="flat", padding=(10, 5))
            style.map("TButton",
                      background=[("active", BUTTON_HOVER_COLOR)],
                      foreground=[("active", TEXT_COLOR)])

            style.configure("Accent.TButton", background=ACCENT_BLUE, foreground=TEXT_COLOR)
            style.map("Accent.TButton",
                      background=[("active", BUTTON_HOVER_COLOR)])

            style.configure("Green.TButton", background=ACCENT_GREEN, foreground=TEXT_COLOR)
            style.map("Green.TButton",
                      background=[("active", BUTTON_HOVER_COLOR)])

            style.configure("Red.TButton", background=ACCENT_RED, foreground=TEXT_COLOR)
            style.map("Red.TButton",
                      background=[("active", BUTTON_HOVER_COLOR)])

            # Card specific styles (for the old grid view, still useful)
            style.configure("Card.TFrame", background=CARD_BG, relief="solid", borderwidth=1, bordercolor="#444444")
            style.configure("CardTitle.TLabel", font=("Arial", 14, "bold"), foreground=TEXT_COLOR, background=CARD_BG)
            style.configure("CardText.TLabel", font=("Arial", 9), foreground=SECONDARY_TEXT_COLOR, background=CARD_BG)
            style.configure("CardRequirements.TLabel", font=("Arial", 9), foreground=TEXT_COLOR, background=CARD_BG)

            # Status badge styles
            style.configure("Status.TLabel", font=("Arial", 9, "bold"), foreground=TEXT_COLOR, padding=(8, 4),
                            relief="flat", borderwidth=0)
            style.configure("Applied.Status.TLabel", background=STATUS_APPLIED_COLOR)
            style.configure("Pending.Status.TLabel", background=STATUS_PENDING_COLOR, foreground="#333333")
            style.configure("Rejected.Status.TLabel", background=STATUS_REJECTED_COLOR)
            style.configure("Draft.Status.TLabel", background=STATUS_DRAFT_COLOR)
            style.configure("Awarded.Status.TLabel", background=ACCENT_GREEN)
            style.configure("Cancelled.Status.TLabel", background=STATUS_REJECTED_COLOR)
            style.configure("Completed.Status.TLabel", background=STATUS_APPLIED_COLOR)

            # Form specific styles
            style.configure("TEntry", fieldbackground=FIELD_BG, foreground=FIELD_TEXT, borderwidth=1, relief="solid",
                            bordercolor="#555555")
            style.configure("TRadiobutton", background=CARD_BG, foreground=TEXT_COLOR,
                            font=("Arial", 9))
            style.map("TRadiobutton",
                      background=[("active", CARD_BG), ("selected", CARD_BG)],
                      foreground=[("active", TEXT_COLOR), ("selected", TEXT_COLOR)])

            style.configure("TCombobox", fieldbackground=FIELD_BG, foreground=FIELD_TEXT)
            self.root.option_add('*TCombobox*Listbox.background', FIELD_BG)
            self.root.option_add('*TCombobox*Listbox.foreground', FIELD_TEXT)
            self.root.option_add('*TCombobox*Listbox.selectBackground', ACCENT_BLUE)
            self.root.option_add('*TCombobox*Listbox.selectForeground', TEXT_COLOR)

            # Treeview styles for the Dashboard list and Log Viewer
            style.configure("Treeview",
                            background=FIELD_BG, # Background for the rows
                            foreground=FIELD_TEXT, # Text color for rows
                            fieldbackground=FIELD_BG, # Background of the entire treeview widget
                            rowheight=25)
            style.map('Treeview', background=[('selected', ACCENT_BLUE)])

            style.configure("Treeview.Heading",
                            font=("Arial", 10, "bold"),
                            background="#3A3A3A", # Slightly lighter heading for contrast
                            foreground=TEXT_COLOR, # Text color for headings
                            relief="flat")
            style.map("Treeview.Heading",
                      background=[('active', "#4A4A4A")])


            print("DEBUG: _setup_styles method completed successfully.")
        except Exception as e:
            print(f"ERROR: Error in _setup_styles: {e}")
            traceback.print_exc()
            raise

    def clear_screen(self):
        """ Clears all widgets from the root window. """
        print("DEBUG: clear_screen called.")
        for widget in self.root.winfo_children():
            widget.destroy()
        print("DEBUG: clear_screen completed.")

    def display_dashboard(self):
        """ Displays the main dashboard with summary and scholarship list."""
        print("DEBUG: display_dashboard started.")
        try:
            self.clear_screen()
            self.all_scholarships = database.fetch_all()

            # --- Header / Title ---
            header_frame = tk.Frame(self.root, bg=PRIMARY_BG)
            header_frame.pack(fill="x", padx=20, pady=10, anchor="n")
            tk.Label(header_frame, text="Scholarship Dashboard", font=("Arial", 20, "bold"), fg=TEXT_COLOR, bg=PRIMARY_BG).pack(side="left")

            # --- Top Info Cards ---
            top_info_frame = tk.Frame(self.root, bg=PRIMARY_BG, padx=20, pady=10)
            top_info_frame.pack(fill="x", anchor="n")

            # Calculate Totals
            total_scholarship_amount = 0
            total_awarded = 0
            total_disbursed = 0

            for sch in self.all_scholarships:
                try:
                    amount_str = sch.get("amount", "₱0").replace("₱", "").replace(",", "").strip()
                    total_scholarship_amount += float(amount_str)
                except ValueError:
                    pass

                try:
                    awarded_str = sch.get("awarded_amount", "₱0").replace("₱", "").replace(",", "").strip()
                    total_awarded += float(awarded_str)
                except ValueError:
                    pass

                try:
                    disbursed_str = sch.get("disbursed_amount", "₱0").replace("₱", "").replace(",", "").strip()
                    total_disbursed += float(disbursed_str)
                except ValueError:
                    pass

            total_outstanding_balance = total_awarded - total_disbursed
            today_date = datetime.date.today().strftime("%B %d, %Y")

            # Function to create info card
            def create_info_card(parent, title, value, date_button_command=None):
                card = tk.Frame(parent, bg=CARD_BG, relief="solid", bd=1, highlightbackground="#444444", highlightthickness=1)
                card.pack(side="left", padx=10, pady=5, fill="both", expand=True)
                card.grid_propagate(False)

                tk.Label(card, text=title, font=("Arial", 10, "bold"), fg=SECONDARY_TEXT_COLOR, bg=CARD_BG, anchor="w").pack(padx=15, pady=(10, 0), fill="x")

                # The image shows an edit button next to "Today's Date" - assuming this is for some setting
                # For now, it's just a placeholder button.
                if title == "Today's Date": # Specific case for the date card
                    value_frame = tk.Frame(card, bg=CARD_BG)
                    value_frame.pack(padx=15, pady=(5, 10), fill="x", expand=True)
                    tk.Label(value_frame, text=value, font=("Arial", 16, "bold"), fg=TEXT_COLOR, bg=CARD_BG, anchor="w").pack(side="left")
                    ttk.Button(value_frame, text="⚙", command=lambda: messagebox.showinfo("Info", "Settings for Date/Dashboard not yet implemented."), style="Green.TButton", width=3).pack(side="right", padx=(5,0))
                else:
                    tk.Label(card, text=value, font=("Arial", 16, "bold"), fg=TEXT_COLOR, bg=CARD_BG, anchor="w").pack(padx=15, pady=(5, 10), fill="x")

                return card

            create_info_card(top_info_frame, "Total Scholarship Amount", f"₱{total_scholarship_amount:,.0f}")
            create_info_card(top_info_frame, "Total Outstanding Balance", f"₱{total_outstanding_balance:,.2f}")
            create_info_card(top_info_frame, "Today's Date", today_date)

            # --- Scholarship List Section ---
            list_section_frame = tk.Frame(self.root, bg=PRIMARY_BG, padx=20, pady=10)
            list_section_frame.pack(fill="both", expand=True)

            list_section_top_bar = tk.Frame(list_section_frame, bg=PRIMARY_BG)
            list_section_top_bar.pack(fill="x", pady=(0,5))
            tk.Label(list_section_top_bar, text="Scholarship List", font=("Arial", 14, "bold"), fg=TEXT_COLOR, bg=PRIMARY_BG, anchor="w").pack(side="left", fill="x", expand=True)
            ttk.Button(list_section_top_bar, text="+ Add Scholarship", command=lambda: self.edit_form(None),
                       style="Green.TButton").pack(side="right", padx=(10, 0))
            ttk.Button(list_section_top_bar, text="View Card Grid", command=self.display_scholarship_grid,
                       style="Accent.TButton").pack(side="right")
            ttk.Button(list_section_top_bar, text="View Activity Log", command=self.show_activity_log,
                       style="Accent.TButton").pack(side="right", padx=(10, 0))

            # Treeview for the Scholarship List
            tree_frame = tk.Frame(list_section_frame, bg=CARD_BG, relief="solid", bd=1, highlightbackground="#444444", highlightthickness=1)
            tree_frame.pack(fill="both", expand=True, padx=5, pady=5)

            tree_scrollbar_y = ttk.Scrollbar(tree_frame, orient="vertical")
            tree_scrollbar_x = ttk.Scrollbar(tree_frame, orient="horizontal")

            self.scholarship_list_tree = ttk.Treeview(
                tree_frame,
                columns=("Name", "Amount", "Balance", "Actions"),
                show="headings",
                yscrollcommand=tree_scrollbar_y.set,
                xscrollcommand=tree_scrollbar_x.set
            )
            self.scholarship_list_tree.pack(side="left", fill="both", expand=True)

            tree_scrollbar_y.config(command=self.scholarship_list_tree.yview)
            tree_scrollbar_x.config(command=self.scholarship_list_tree.xview)
            tree_scrollbar_y.pack(side="right", fill="y")
            tree_scrollbar_x.pack(side="bottom", fill="x")

            # Configure Treeview Headings
            self.scholarship_list_tree.heading("Name", text="Name", anchor="w")
            self.scholarship_list_tree.heading("Amount", text="Amount", anchor="w")
            self.scholarship_list_tree.heading("Balance", text="Balance", anchor="w")
            self.scholarship_list_tree.heading("Actions", text="Actions", anchor="center")

            # Configure Treeview Columns
            self.scholarship_list_tree.column("Name", width=250, minwidth=150, stretch=tk.YES)
            self.scholarship_list_tree.column("Amount", width=120, minwidth=100, stretch=tk.NO)
            self.scholarship_list_tree.column("Balance", width=120, minwidth=100, stretch=tk.NO)
            self.scholarship_list_tree.column("Actions", width=80, minwidth=70, stretch=tk.NO, anchor="center")

            # Apply Treeview styles defined in _setup_styles
            self.scholarship_list_tree.config(style="Treeview") # Use the general Treeview style

            self.populate_dashboard_list()

            # Bind double-click to open edit form
            self.scholarship_list_tree.bind("<Double-1>", self.on_list_item_double_click)
            # Bind <Return> key as well for accessibility
            self.scholarship_list_tree.bind("<Return>", self.on_list_item_double_click)


            print("DEBUG: display_dashboard completed successfully.")
        except Exception as e:
            print(f"ERROR: An unhandled error occurred in display_dashboard: {e}")
            traceback.print_exc()
            messagebox.showerror("Dashboard Error", f"Failed to display dashboard: {e}\nCheck console for details.")

    def populate_dashboard_list(self):
        """ Populates the Treeview in the dashboard list."""
        print("DEBUG: populate_dashboard_list started.")
        # Clear existing items
        for item in self.scholarship_list_tree.get_children():
            self.scholarship_list_tree.delete(item)

        for sch in self.all_scholarships:
            name = sch.get("name", "N/A")
            amount = sch.get("amount", "₱0")
            awarded = sch.get("awarded_amount", "₱0")
            disbursed = sch.get("disbursed_amount", "₱0")

            try:
                clean_awarded = float(awarded.replace("₱", "").replace(",", "").strip())
                clean_disbursed = float(disbursed.replace("₱", "").replace(",", "").strip())
                balance = clean_awarded - clean_disbursed
                formatted_balance = f"₱{balance:,.2f}"
            except ValueError:
                formatted_balance = "N/A"

            # Insert data into the Treeview
            # We'll put "EDIT" text and rely on double-click for action, or you can add a button overlay
            item_id = self.scholarship_list_tree.insert("", "end", values=(name, amount, formatted_balance, "EDIT"))
            self.scholarship_list_tree.item(item_id, tags=(name,)) # Tag item with scholarship name for lookup

        print("DEBUG: populate_dashboard_list completed.")

    def on_list_item_double_click(self, event):
        """ Handles double-click on a Treeview item to show details or edit."""
        selected_items = self.scholarship_list_tree.selection()
        if not selected_items:
            return

        item = selected_items[0]
        # Get the name from tags, assuming the first tag is the scholarship name
        scholarship_name = self.scholarship_list_tree.item(item, "tags")[0]

        # Find the full scholarship data
        selected_scholarship_data = next((sch for sch in self.all_scholarships if sch["name"] == scholarship_name), None)

        if selected_scholarship_data:
            self.edit_form(selected_scholarship_data)
        else:
            messagebox.showerror("Error", "Scholarship data not found.")

    def display_scholarship_grid(self):
        """ Displays the main grid of scholarship cards. """
        print("DEBUG: display_scholarship_grid started.")
        try:
            self.clear_screen()
            self.all_scholarships = database.fetch_all()
            self.displayed_scholarships = list(self.all_scholarships)
            print(f"DEBUG: Fetched {len(self.all_scholarships)} scholarships.")

            top_bar_frame = tk.Frame(self.root, bg=PRIMARY_BG)
            top_bar_frame.pack(fill="x", padx=20, pady=10)

            tk.Label(top_bar_frame, text="My Scholarships", font=("Arial", 20, "bold"), fg=TEXT_COLOR,
                     bg=PRIMARY_BG).pack(
                side="left")

            ttk.Button(top_bar_frame, text="+ Add Scholarship", command=lambda: self.edit_form(None),
                       style="Green.TButton").pack(side="left", padx=(20, 0))

            ttk.Button(top_bar_frame, text="View Activity Log", command=self.show_activity_log,
                       style="Accent.TButton").pack(side="left", padx=(10, 0))

            ttk.Button(top_bar_frame, text="View Dashboard", command=self.display_dashboard,
                       style="Accent.TButton").pack(side="left", padx=(10, 0))


            search_frame = tk.Frame(top_bar_frame, bg=PRIMARY_BG)
            search_frame.pack(side="right", padx=10)

            self.search_entry_var = tk.StringVar()
            self.search_entry_var.trace("w", self.filter_scholarships)

            ttk.Entry(search_frame, textvariable=self.search_entry_var, width=30, style="TEntry",
                      font=("Arial", 10), foreground=FIELD_TEXT, background=FIELD_BG).pack(side="right", padx=(5, 0))
            tk.Label(search_frame, text="Q Search scholarships...", font=("Arial", 10), fg=SECONDARY_TEXT_COLOR,
                     bg=PRIMARY_BG).pack(side="right")

            cards_container = tk.Frame(self.root, bg=PRIMARY_BG, padx=15, pady=15)
            cards_container.pack(fill="both", expand=True)

            canvas = tk.Canvas(cards_container, bg=PRIMARY_BG, highlightthickness=0)
            canvas.pack(side="left", fill="both", expand=True)

            scrollbar = ttk.Scrollbar(cards_container, orient="vertical", command=canvas.yview)
            scrollbar.pack(side="right", fill="y")

            canvas.configure(yscrollcommand=scrollbar.set)

            self.scrollable_frame = tk.Frame(canvas, bg=PRIMARY_BG)
            self.canvas_frame_id = canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw",
                                                        width=1)

            def _on_canvas_configure(event=None):
                canvas.configure(scrollregion=canvas.bbox("all"))
                canvas.itemconfig(self.canvas_frame_id, width=canvas.winfo_width())

            self.scrollable_frame.bind("<Configure>", _on_canvas_configure)
            canvas.bind('<Configure>', _on_canvas_configure)

            self.render_scholarship_cards(self.displayed_scholarships)

            self.root.update_idletasks()
            _on_canvas_configure()
            print("DEBUG: display_scholarship_grid completed successfully.")

        except Exception as e:
            print(f"ERROR: An unhandled error occurred in display_scholarship_grid: {e}")
            traceback.print_exc()
            messagebox.showerror("Display Error", f"Failed to display scholarships: {e}\nCheck console for details.")

    def filter_scholarships(self, *args):
        """ Filters scholarships based on the search entry. """
        print("DEBUG: filter_scholarships called.")
        try:
            search_term = self.search_entry_var.get().lower()
            if not search_term:
                self.displayed_scholarships = list(self.all_scholarships)
            else:
                self.displayed_scholarships = [
                    sch for sch in self.all_scholarships
                    if search_term in sch.get("name", "").lower() or
                       search_term in sch.get("provider", "").lower() or
                       search_term in sch.get("status", "").lower() or
                       search_term in sch.get("description", "").lower() or
                       search_term in sch.get("requirements", "").lower()
                ]
            self.render_scholarship_cards(self.displayed_scholarships)
            self.root.update_idletasks()
            if hasattr(self, 'scrollable_frame') and self.scrollable_frame.master:
                self.scrollable_frame.master.configure(scrollregion=self.scrollable_frame.master.bbox("all"))
            print("DEBUG: filter_scholarships completed.")
        except Exception as e:
            print(f"ERROR: Error in filter_scholarships: {e}")
            traceback.print_exc()
            messagebox.showerror("Filter Error", f"An error occurred during filtering: {e}")

    def render_scholarship_cards(self, scholarship_list):
        """ Renders the scholarship cards in the scrollable frame. """
        print("DEBUG: render_scholarship_cards started.")
        try:
            for widget in self.scrollable_frame.winfo_children():
                widget.destroy()

            col_count = 2
            if not scholarship_list:
                print("DEBUG: No scholarships to display.")
                tk.Label(self.scrollable_frame, text="No scholarships found.", fg=SECONDARY_TEXT_COLOR, bg=PRIMARY_BG,
                         font=("Arial", 12)).pack(pady=50)
                return

            self.scrollable_frame.grid_columnconfigure(0, weight=1)
            self.scrollable_frame.grid_columnconfigure(1, weight=1)

            for i, data in enumerate(scholarship_list):
                row = i // col_count
                col = i % col_count
                print(f"DEBUG: Creating card for {data.get('name')} at row {row}, col {col}")
                self.create_scholarship_card(self.scrollable_frame, data, row, col)
            print("DEBUG: render_scholarship_cards completed.")
        except Exception as e:
            print(f"ERROR: Error in render_scholarship_cards: {e}")
            traceback.print_exc()
            messagebox.showerror("Render Error", f"Failed to render scholarship cards: {e}")

    def create_scholarship_card(self, parent_frame, data, row, col):
        """ Creates and places a single scholarship card. """
        print(f"DEBUG: create_scholarship_card started for {data.get('name')}")
        try:
            card_frame = ttk.Frame(parent_frame, style="Card.TFrame", padding=20)
            card_frame.grid(row=row, column=col, padx=15, pady=15, sticky="nsew")

            header_frame = tk.Frame(card_frame, bg=CARD_BG)
            header_frame.pack(fill="x", pady=(0, 10))

            tk.Label(header_frame, text=data.get("name", "N/A"), font=("Arial", 14, "bold"), fg=TEXT_COLOR, bg=CARD_BG,
                     wraplength=300, anchor="w").pack(side="left", fill="x", expand=True)

            icon_frame = tk.Frame(header_frame, bg=CARD_BG)
            icon_frame.pack(side="right", padx=(10, 0))

            edit_icon_label = tk.Label(icon_frame, text="✎", fg=EDIT_ICON_COLOR, bg=CARD_BG, font=("Arial", 12),
                                       cursor="hand2")
            edit_icon_label.pack(side="left", padx=5)
            edit_icon_label.bind("<Button-1>", lambda e, d=data: self.edit_form(d))
            edit_icon_label.bind("<Enter>", lambda e, l=edit_icon_label: l.config(fg="white"))
            edit_icon_label.bind("<Leave>", lambda e, l=edit_icon_label: l.config(fg=EDIT_ICON_COLOR))

            delete_icon_label = tk.Label(icon_frame, text="🗑", fg=DELETE_ICON_COLOR, bg=CARD_BG, font=("Arial", 12),
                                         cursor="hand2")
            delete_icon_label.pack(side="left")
            delete_icon_label.bind("<Button-1>", lambda e, d=data: self.confirm_delete(d))
            delete_icon_label.bind("<Enter>", lambda e, l=delete_icon_label: l.config(fg="white"))
            delete_icon_label.bind("<Leave>", lambda e, l=delete_icon_label: l.config(fg=DELETE_ICON_COLOR))

            status = data.get("status", "N/A")
            if status == "Rejected" or status == "Cancelled":
                status_style = "Rejected.Status.TLabel"
            elif status == "Pending":
                status_style = "Pending.Status.TLabel"
            elif status == "Applied" or status == "Awarded" or status == "Completed":
                status_style = "Applied.Status.TLabel"
            else:
                status_style = "Draft.Status.TLabel"

            status_label = ttk.Label(card_frame, text=f"Status: {status}", style=status_style)
            status_label.pack(side="top", anchor="ne", pady=(0, 10))

            details_frame = tk.Frame(card_frame, bg=CARD_BG)
            details_frame.pack(fill="x", anchor="nw")

            def add_detail(label_text, value):
                tk.Label(details_frame, text=label_text, font=("Arial", 9), fg=SECONDARY_TEXT_COLOR, bg=CARD_BG,
                         anchor="w").pack(fill="x")
                tk.Label(details_frame, text=value, font=("Arial", 10), fg=TEXT_COLOR, bg=CARD_BG, anchor="w",
                         wraplength=300).pack(fill="x", pady=(0, 5))

            add_detail("Provider", data.get("provider", "N/A"))
            add_detail("Application Deadline", data.get("deadline", "N/A"))
            add_detail("Disbursement Date", data.get("disbursement_date", "N/A"))
            add_detail("Amount", data.get("amount", "N/A"))
            add_detail("Renewable", data.get("renewable", "N/A"))

            tk.Label(card_frame, text="Requirements", font=("Arial", 10, "bold"), fg=TEXT_COLOR, bg=CARD_BG,
                     anchor="w").pack(fill="x", pady=(10, 0))
            requirements_text = tk.Label(card_frame, text=data.get("requirements", "N/A"), font=("Arial", 9),
                                         fg=TEXT_COLOR,
                                         bg=CARD_BG, anchor="nw", justify="left", wraplength=300)
            requirements_text.pack(fill="both", expand=True)

            ttk.Button(card_frame, text="View Details", style="Accent.TButton",
                       command=lambda d=data: self.show_details(d)).pack(pady=(15, 0), fill="x")
            print(f"DEBUG: create_scholarship_card completed for {data.get('name')}")
        except Exception as e:
            print(f"ERROR: Error in create_scholarship_card for {data.get('name')}: {e}")
            traceback.print_exc()
            messagebox.showerror("Card Creation Error", f"Failed to create card for {data.get('name')}: {e}")

    def show_details(self, data):
        """ Displays detailed information of a selected scholarship. """
        print(f"DEBUG: show_details started for {data.get('name')}")
        try:
            self.clear_screen()
            self.current_data = data
            self.original_scholarship_name = data.get("name")

            tk.Label(self.root, text="SCHOLARSHIP DETAILS", font=("Arial", 18, "bold"), bg=PRIMARY_BG,
                     fg=TEXT_COLOR).pack(
                pady=10)

            frame = tk.Frame(self.root, bg=CARD_BG, padx=30, pady=20, relief="solid", bd=1,
                             highlightbackground="#444444",
                             highlightthickness=1)
            frame.pack(padx=30, pady=10, fill="both", expand=True)

            frame.grid_columnconfigure(0, weight=1)
            frame.grid_columnconfigure(1, weight=3)

            def add_row(parent, label_text, value, row_idx):
                ttk.Label(parent, text=label_text, font=("Arial", 10, "bold"), foreground=SECONDARY_TEXT_COLOR,
                          background=CARD_BG, anchor="w").grid(row=row_idx, column=0, sticky="nw", pady=5, padx=5)
                tk.Label(parent, text=value, font=("Arial", 10), foreground=TEXT_COLOR, background=CARD_BG, anchor="w",
                         wraplength=600, justify="left").grid(row=row_idx, column=1, sticky="nw", pady=5, padx=5)

            fields_to_display = [
                ("Scholarship Name", "name"),
                ("Provider", "provider"),
                ("Amount", "amount"),
                ("Awarded Amount", "awarded_amount"), # Added
                ("Disbursed Amount", "disbursed_amount"), # Added
                ("Application Deadline", "deadline"),
                ("Disbursement Date", "disbursement_date"),
                ("Status", "status"),
                ("Renewable", "renewable"),
                ("Description", "description"),
                ("Requirements", "requirements"),
                ("Notes", "notes")
            ]

            for i, (label, key) in enumerate(fields_to_display):
                add_row(frame, label, data.get(key, "N/A"), i)

            button_frame = tk.Frame(self.root, bg=PRIMARY_BG)
            button_frame.pack(pady=20)

            ttk.Button(button_frame, text="Back to Dashboard", command=self.display_dashboard, # Changed to dashboard
                       style="Accent.TButton").pack(side="left", padx=10)
            ttk.Button(button_frame, text="Edit Scholarship", command=lambda: self.edit_form(data),
                       style="Accent.TButton").pack(side="left", padx=10)
            ttk.Button(button_frame, text="Delete Scholarship", command=lambda: self.confirm_delete(data),
                       style="Red.TButton").pack(side="left", padx=10)
            print("DEBUG: show_details completed.")
        except Exception as e:
            print(f"ERROR: Error in show_details: {e}")
            traceback.print_exc()
            messagebox.showerror("Details Error", f"Failed to show scholarship details: {e}")

    def confirm_delete(self, data):
        """ Asks for confirmation before deleting a scholarship. """
        print(f"DEBUG: confirm_delete called for {data.get('name')}")
        scholarship_name = data.get("name", "Unknown Scholarship")
        confirm = messagebox.askyesno("Confirm Delete",
                                      f"Are you sure you want to delete '{scholarship_name}'?\n\nThis action cannot be undone.",
                                      icon='warning')
        if confirm:
            try:
                database.delete(scholarship_name)
                today = datetime.datetime.now().strftime("%Y-%m-%d")
                # Use current awarded/disbursed for logging deletion
                database.insert_log(today, scholarship_name, data.get("awarded_amount", "₱0"), data.get("disbursed_amount", "N/A"), "Deleted")
                messagebox.showinfo("Success", f"'{scholarship_name}' deleted successfully.")
                self.display_dashboard() # Changed to dashboard
                print(f"DEBUG: {scholarship_name} deleted successfully.")
            except ValueError as e:
                messagebox.showerror("Error", f"Failed to delete scholarship: {e}")
                print(f"ERROR: Deletion ValueError: {e}")
            except Exception as e:
                messagebox.showerror("Error", f"An unexpected error occurred: {e}")
                print(f"ERROR: Deletion unexpected error: {e}")
            traceback.print_exc()

    def edit_form(self, data=None):
        """ Opens a form to add or edit a scholarship.
            If data is None, it's a new scholarship.
        """
        print(f"DEBUG: edit_form called. New scholarship: {data is None}")
        try:
            self.clear_screen()
            is_new = (data is None)
            self.current_data = data if not is_new else {}
            self.original_scholarship_name = self.current_data.get("name") if not is_new else None

            title_text = "ADD NEW SCHOLARSHIP" if is_new else "EDIT SCHOLARSHIP"
            tk.Label(self.root, text=title_text, font=("Arial", 18, "bold"), bg=PRIMARY_BG, fg=TEXT_COLOR).pack(pady=10)

            form_frame = tk.Frame(self.root, bg=CARD_BG, padx=30, pady=20, relief="solid", bd=1,
                                  highlightbackground="#444444", highlightthickness=1)
            form_frame.pack(padx=30, pady=10, fill="both", expand=True)

            form_frame.grid_columnconfigure(0, weight=1)
            form_frame.grid_columnconfigure(1, weight=3)

            entries = {}
            row_idx = 0

            def add_entry_row(parent, label_text, key, initial_value="", is_text_area=False, height=4):
                nonlocal row_idx
                ttk.Label(parent, text=label_text, foreground=SECONDARY_TEXT_COLOR, background=CARD_BG,
                          font=("Arial", 10, "bold"), anchor="w").grid(row=row_idx, column=0, sticky="nw", pady=5,
                                                                       padx=5)
                if is_text_area:
                    text_frame = tk.Frame(parent, bg=FIELD_BG, borderwidth=1, relief="solid",
                                          highlightbackground="#555555")
                    text_widget = tk.Text(text_frame, height=height, width=50, font=("Arial", 10),
                                          bg=FIELD_BG, fg=FIELD_TEXT, insertbackground=FIELD_TEXT,
                                          relief="flat", highlightthickness=0)
                    text_widget.pack(side="left", fill="both", expand=True)

                    text_scrollbar = ttk.Scrollbar(text_frame, orient="vertical", command=text_widget.yview)
                    text_scrollbar.pack(side="right", fill="y")
                    text_widget.config(yscrollcommand=text_scrollbar.set)

                    text_widget.insert("1.0", initial_value)
                    text_frame.grid(row=row_idx, column=1, sticky="ew", pady=5, padx=5)
                    entries[key] = text_widget
                else:
                    widget = ttk.Entry(parent, style="TEntry", font=("Arial", 10))
                    widget.insert(0, initial_value)
                    widget.grid(row=row_idx, column=1, sticky="ew", pady=5, padx=5)
                    entries[key] = widget
                row_idx += 1

            add_entry_row(form_frame, "Scholarship Name:", "name", self.current_data.get("name", ""))
            if not is_new:
                entries["name"].config(state="readonly")
                ttk.Label(form_frame, text=" (Cannot be changed)", foreground=SECONDARY_TEXT_COLOR, background=CARD_BG,
                          font=("Arial", 8)).grid(row=row_idx - 1, column=2, sticky="w")

            add_entry_row(form_frame, "Provider:", "provider", self.current_data.get("provider", ""))
            add_entry_row(form_frame, "Amount (e.g., ₱10,000):", "amount", self.current_data.get("amount", ""))
            add_entry_row(form_frame, "Awarded Amount (e.g., ₱10,000):", "awarded_amount", self.current_data.get("awarded_amount", "₱0")) # NEW FIELD
            add_entry_row(form_frame, "Disbursed Amount (e.g., ₱5,000):", "disbursed_amount", self.current_data.get("disbursed_amount", "₱0")) # NEW FIELD
            add_entry_row(form_frame, "Application Deadline (YYYY-MM-DD):", "deadline",
                          self.current_data.get("deadline", ""))
            add_entry_row(form_frame, "Disbursement Date (YYYY-MM-DD):", "disbursement_date",
                          self.current_data.get("disbursement_date", ""))

            add_entry_row(form_frame, "Description:", "description", self.current_data.get("description", ""),
                          is_text_area=True, height=3)
            add_entry_row(form_frame, "Requirements:", "requirements", self.current_data.get("requirements", ""),
                          is_text_area=True, height=5)
            add_entry_row(form_frame, "Notes:", "notes", self.current_data.get("notes", ""),
                          is_text_area=True, height=3)

            # Status Dropdown
            ttk.Label(form_frame, text="Status:", foreground=SECONDARY_TEXT_COLOR, background=CARD_BG,
                      font=("Arial", 10, "bold"), anchor="w").grid(row=row_idx, column=0, sticky="nw", pady=5, padx=5)
            status_options = ["Draft", "Applied", "Pending", "Awarded", "Rejected", "Cancelled", "Completed"]
            status_var = tk.StringVar(value=self.current_data.get("status", status_options[0]))
            status_combobox = ttk.Combobox(form_frame, textvariable=status_var, values=status_options,
                                           state="readonly", font=("Arial", 10), style="TCombobox")
            status_combobox.grid(row=row_idx, column=1, sticky="ew", pady=5, padx=5)
            entries["status"] = status_var
            row_idx += 1

            # Renewable Radio Buttons
            ttk.Label(form_frame, text="Renewable:", foreground=SECONDARY_TEXT_COLOR, background=CARD_BG,
                      font=("Arial", 10, "bold"), anchor="w").grid(row=row_idx, column=0, sticky="nw", pady=5, padx=5)
            renewable_frame = tk.Frame(form_frame, bg=CARD_BG)
            renewable_frame.grid(row=row_idx, column=1, sticky="ew", pady=5, padx=5)
            renewable_var = tk.StringVar(value=self.current_data.get("renewable", "No"))

            tk.Radiobutton(renewable_frame, text="Yes", variable=renewable_var, value="Yes",
                           bg=CARD_BG, fg=TEXT_COLOR, selectcolor=CARD_BG, activebackground=CARD_BG,
                           activeforeground=TEXT_COLOR, font=("Arial", 10),
                           indicatoron=0,
                           width=8, relief="flat", overrelief="raised", borderwidth=1,
                           highlightbackground="#555555", highlightthickness=1
                           ).pack(side="left", padx=(0, 10))
            tk.Radiobutton(renewable_frame, text="No", variable=renewable_var, value="No",
                           bg=CARD_BG, fg=TEXT_COLOR, selectcolor=CARD_BG, activebackground=CARD_BG,
                           activeforeground=TEXT_COLOR, font=("Arial", 10),
                           indicatoron=0,
                           width=8, relief="flat", overrelief="raised", borderwidth=1,
                           highlightbackground="#555555", highlightthickness=1
                           ).pack(side="left")
            entries["renewable"] = renewable_var
            row_idx += 1

            button_frame = tk.Frame(self.root, bg=PRIMARY_BG)
            button_frame.pack(pady=20)

            save_command = lambda: self.save_scholarship(is_new, entries)
            ttk.Button(button_frame, text="Save Scholarship", command=save_command,
                       style="Green.TButton").pack(side="left", padx=10)
            ttk.Button(button_frame, text="Cancel", command=self.display_dashboard, # Changed to dashboard
                       style="Red.TButton").pack(side="left", padx=10)

            print("DEBUG: edit_form completed.")
        except Exception as e:
            print(f"ERROR: Error in edit_form: {e}")
            traceback.print_exc()
            messagebox.showerror("Form Error", f"Failed to open scholarship form: {e}")

    def _validate_and_get_form_data(self, entries):
        """ Validates form entries and returns a dictionary of data. """
        print("DEBUG: _validate_and_get_form_data started.")
        data = {}
        required_fields = ["name", "provider", "amount", "deadline"]
        date_fields = ["deadline", "disbursement_date"]

        for key, widget in entries.items():
            if isinstance(widget, tk.Text):
                value = widget.get("1.0", tk.END).strip()
            elif isinstance(widget, tk.StringVar):
                value = widget.get()
            else:
                value = widget.get().strip()
            data[key] = value

            if key in required_fields and not value:
                messagebox.showerror("Validation Error", f"'{key.replace('_', ' ').title()}' is a required field.")
                print(f"VALIDATION ERROR: Missing required field: {key}")
                return None

        # Specific validations for amount, awarded_amount, disbursed_amount
        numeric_fields = ["amount", "awarded_amount", "disbursed_amount"]
        for field in numeric_fields:
            if field in data and data[field]:
                try:
                    clean_value = data[field].replace("₱", "").replace(",", "").strip()
                    num_value = float(clean_value)
                    data[field] = f"₱{num_value:,.0f}" # Standardize format
                except ValueError:
                    messagebox.showerror("Validation Error", f"'{field.replace('_', ' ').title()}' must be a valid number.")
                    print(f"VALIDATION ERROR: Invalid numeric format for {field}: {data[field]}")
                    return None

        for field in date_fields:
            if field in data and data[field]:
                try:
                    datetime.datetime.strptime(data[field], "%Y-%m-%d")
                except ValueError:
                    messagebox.showerror("Validation Error",
                                         f"'{field.replace('_', ' ').title()}' must be in YYYY-MM-DD format.")
                    print(f"VALIDATION ERROR: Invalid date format for {field}: {data[field]}")
                    return None
        print("DEBUG: _validate_and_get_form_data completed successfully.")
        return data

    def save_scholarship(self, is_new, entries):
        """ Saves the scholarship data from the form. """
        print(f"DEBUG: save_scholarship called. Is new: {is_new}")
        data = self._validate_and_get_form_data(entries)
        if data is None:
            print("DEBUG: Data validation failed. Save aborted.")
            return

        scholarship_name = data.get("name")
        old_awarded_amount = self.current_data.get("awarded_amount", "₱0")
        old_disbursed_amount = self.current_data.get("disbursed_amount", "₱0")

        try:
            if is_new:
                database.insert(data)
                today = datetime.datetime.now().strftime("%Y-%m-%d")
                database.insert_log(today, scholarship_name, data.get("awarded_amount", "₱0"), data.get("disbursed_amount", "₱0"), "Added Scholarship")
                messagebox.showinfo("Success", f"'{scholarship_name}' added successfully!")
                print(f"DEBUG: New scholarship '{scholarship_name}' added.")
            else:
                database.update(self.original_scholarship_name, data)
                today = datetime.datetime.now().strftime("%Y-%m-%d")
                # Log if awarded or disbursed amounts have changed
                current_awarded = data.get("awarded_amount", "₱0")
                current_disbursed = data.get("disbursed_amount", "₱0")

                if old_awarded_amount != current_awarded or old_disbursed_amount != current_disbursed:
                    database.insert_log(today, scholarship_name, current_awarded, current_disbursed, "Amount/Disbursement Updated")
                else:
                    database.insert_log(today, scholarship_name, current_awarded, current_disbursed, "Details Updated") # Generic update log
                messagebox.showinfo("Success", f"'{scholarship_name}' updated successfully!")
                print(f"DEBUG: Scholarship '{scholarship_name}' updated.")

            self.display_dashboard() # Refresh to the dashboard view
            # self.root.destroy() # Don't destroy the root, just refresh the content

        except ValueError as e:
            messagebox.showerror("Database Error", f"Operation failed: {e}")
            print(f"ERROR: Database ValueError: {e}")
            traceback.print_exc()
        except Exception as e:
            messagebox.showerror("Error", f"An unexpected error occurred during save: {e}")
            print(f"ERROR: Unexpected save error: {e}")
            traceback.print_exc()

    def show_activity_log(self):
        """Displays the activity log in a new window."""
        print("DEBUG: show_activity_log started.")
        log_window = tk.Toplevel(self.root)
        log_window.title("Scholarship Activity Log")
        log_window.geometry("800x600")
        log_window.configure(bg=PRIMARY_BG)

        # Center the Toplevel window
        log_window.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() // 2) - (log_window.winfo_width() // 2)
        y = self.root.winfo_y() + (self.root.winfo_height() // 2) - (log_window.winfo_height() // 2)
        log_window.geometry(f"+{int(x)}+{int(y)}")

        tk.Label(log_window, text="Activity Log", font=("Arial", 18, "bold"),
                 fg=TEXT_COLOR, bg=PRIMARY_BG).pack(pady=10)

        log_frame_container = tk.Frame(log_window, bg=PRIMARY_BG)
        log_frame_container.pack(fill="both", expand=True, padx=20, pady=10)

        log_canvas = tk.Canvas(log_frame_container, bg=CARD_BG, highlightthickness=0)
        log_canvas.pack(side="left", fill="both", expand=True)

        log_scrollbar = ttk.Scrollbar(log_frame_container, orient="vertical", command=log_canvas.yview)
        log_scrollbar.pack(side="right", fill="y")

        log_canvas.configure(yscrollcommand=log_scrollbar.set)

        scrollable_log_frame = tk.Frame(log_canvas, bg=CARD_BG)
        log_canvas_frame_id = log_canvas.create_window((0, 0), window=scrollable_log_frame, anchor="nw", width=1)

        def _on_log_canvas_configure(event=None):
            log_canvas.configure(scrollregion=log_canvas.bbox("all"))
            log_canvas.itemconfig(log_canvas_frame_id, width=log_canvas.winfo_width())

        scrollable_log_frame.bind("<Configure>", _on_log_canvas_configure)
        log_canvas.bind('<Configure>', _on_log_canvas_configure)


        tree_frame = tk.Frame(scrollable_log_frame, bg=CARD_BG)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=10)

        tree = ttk.Treeview(tree_frame, columns=("Date", "Scholarship Name", "Awarded", "Disbursed", "Action"), show="headings")
        tree.pack(fill="both", expand=True)

        tree.heading("Date", text="Date", anchor="w")
        tree.heading("Scholarship Name", text="Scholarship Name", anchor="w")
        tree.heading("Awarded", text="Awarded Amount", anchor="w") # Updated heading
        tree.heading("Disbursed", text="Disbursed Amount", anchor="w") # Updated heading
        tree.heading("Action", text="Action", anchor="w")

        tree.column("Date", width=100, minwidth=80, stretch=tk.NO)
        tree.column("Scholarship Name", width=250, minwidth=150, stretch=tk.YES)
        tree.column("Awarded", width=120, minwidth=100, stretch=tk.NO)
        tree.column("Disbursed", width=120, minwidth=100, stretch=tk.NO)
        tree.column("Action", width=150, minwidth=100, stretch=tk.YES)

        # Apply Treeview styles for the dark theme (already configured in _setup_styles)
        tree.config(style="Treeview")

        logs = database.logs
        for log_entry in logs:
            tree.insert("", "end", values=(
                log_entry.get("date", "N/A"),
                log_entry.get("name", "N/A"),
                log_entry.get("awarded", "N/A"), # Now logs awarded amount
                log_entry.get("disbursed", "N/A"), # Now logs disbursed amount
                log_entry.get("action", "N/A")
            ))

        ttk.Button(log_window, text="Close", command=log_window.destroy,
                   style="Accent.TButton").pack(pady=10)

        log_window.grab_set()
        self.root.wait_window(log_window)

        print("DEBUG: show_activity_log completed.")


if __name__ == "__main__":
    root = tk.Tk()
    app = ScholarshipApp(root)
    root.mainloop()